// This file is part of RockstarEditorPlus.
// Derived from RageOpenV by Chiheb Bacha
// (https://github.com/Chiheb-Bacha/RageOpenV), GPL-3.0.
// Copyright (C) Chiheb Bacha (RageOpenV)
// Copyright (C) 2026 CoreFX (crxhvrd@proton.me) — RockstarEditorPlus modifications
//   (distinct trampoline-slab address so both ASIs can coexist)
// SPDX-License-Identifier: GPL-3.0-only
// RockstarEditorPlus is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License v3 as published by the Free
// Software Foundation. See the LICENSE file for details.

#pragma once
#include <cstdint>
#include <vector>
#include <functional>
#include <string>
#include <Windows.h>
#include "vendor/minhook/include/MinHook.h"
#include "log.h"

class memory {
public:
	uintptr_t address;
	memory(memory& other) : address(other.address) {}
	memory(uintptr_t offset, bool useBase = false) : address(useBase ? base() + offset : offset) {}

	struct InitFuncs
	{
		std::function<void()> fn;
		static std::vector<InitFuncs>& funcs()
		{
			static std::vector<InitFuncs> _funcs;
			return _funcs;
		}

		static void run()
		{
			for (auto& cb : funcs())
			{
				cb.fn();
			}
		}

		InitFuncs(const std::function<void()>& fn) : fn(fn)
		{
			funcs().push_back(*this);
		}
	};

	inline static uintptr_t& base()
	{
		static uintptr_t _base;
		return _base;
	}

	// SizeOfImage for the game module, read from its own headers. Used to sanity
	// check anything resolved by interior offset: a RIP-relative operand always
	// points inside the module, so a result outside it means the displacement
	// was read from the wrong place.
	inline static uintptr_t imageSize()
	{
		static uintptr_t _size = [] () -> uintptr_t {
			const uintptr_t b = base();
			if (!b) return 0;
			const auto* dos = (PIMAGE_DOS_HEADER)b;
			const auto* nt  = (PIMAGE_NT_HEADERS)((std::uint8_t*)b + dos->e_lfanew);
			return nt->OptionalHeader.SizeOfImage;
		}();
		return _size;
	}

	inline static memory& virtual_mem()
	{
		static memory _virtualmem(0, false);
		return _virtualmem;
	}

	inline static memory get_virtual_mem(size_t size)
	{
		static memory current = virtual_mem();

		while (current.address % 16) {
			current.address += 1;
		}

		memory res(current);
		current.address += size;
		return res;
	}

	inline static void init()
	{
		memory::base() = (uintptr_t)GetModuleHandle(NULL);
		// IMPORTANT: every ASI sharing this memory.h VirtualAllocs its trampoline
		// slab at a FIXED address. Whichever loads first takes it; the second
		// gets NULL and crashes writing to a null slab (observed with RageOpenV:
		// RageOpenV.asi+0x8881, faultAddr=0). Known claims:
		//   RageOpenV      base()+0x20000000
		//   fxReloader     base()+0x30000000
		//   RockstarEditorPlus base()+0x40000000   <- ours
		// Keep these distinct, and fall back to any free region regardless.
		void* slab = VirtualAlloc((void*)(base() + 0x40000000), 4096, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
		if (!slab)
			slab = VirtualAlloc(NULL, 4096, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
		memory::virtual_mem() = memory((uintptr_t)slab, false);

		auto status = MH_Initialize();
		if (status != MH_OK)
			logger::write("info", "MH_Initialize failed %d", (int)status);
	}

	template <typename T>
	inline T as()
	{
		return (T)(address);
	}

	template <typename T>
	inline memory add(T offset)
	{
		return memory(address + offset);
	}

	inline memory rip()
	{
		return memory(address + *(int32_t*)address + 4);
	}

	inline void nop(size_t len)
	{
		scoped_unlock lock(address, len);
		memset((void*)address, 0x90, len);
	}

	inline void ret()
	{
		put<uint8_t>(0xC3);
	}

	inline void make_jmp(uintptr_t func)
	{
		memory(address, false).put<uint16_t>(0xB848);
		memory(address + 2, false).put<uintptr_t>(func);
		memory(address + 10, false).put<uint16_t>(0xE0FF);
	}

	inline void make_jmp_ret(void* func)
	{
		make_jmp_ret((uintptr_t)func);
	}

	inline void make_jmp_ret(uintptr_t func)
	{
		memory(address, false).put<uint16_t>(0xB848);
		memory(address + 2, false).put<uintptr_t>(func);
		memory(address + 10, false).put<uint16_t>(0xC350);
	}

	inline void make_call(uintptr_t func)
	{
		put<uint8_t>(0xE8);
		memory(address + 1, false).put(int32_t(func - address - 5));
	}

	inline void set_call(void* func, bool ret = false)
	{
		memory jmpMem = get_virtual_mem(12);

		if (ret)
			jmpMem.make_jmp_ret((uintptr_t)func);
		else
			jmpMem.make_jmp((uintptr_t)func);

		make_call(jmpMem.address);
	}

	template<typename T>
	inline void put(const T& value)
	{
		scoped_unlock lock(address, sizeof(T));
		memcpy((void*)address, &value, sizeof(T));
	}

	template <typename R = void*, typename ...Args>
	inline R call(Args... args)
	{
		return ((R(*)(Args...))address)(args...);
	}

	template<class T>
	// Returns false if the detour is not actually in place.
	//
	// It used to return void and log a bare "MH_CreateHook failed 5" with no
	// indication of WHICH hook, while every caller logged its own cheerful
	// "hooked" line regardless. So a failed install and a working one produced
	// the same log, and under FiveM - where the address space is crowded enough
	// that MinHook can genuinely fail to place a trampoline within reach - there
	// was no way to tell which feature had silently not been installed.
	//
	// `what` is optional so the existing call sites still compile; anything that
	// passes it gets its name in the failure line.
	bool hook(T* target, T** orig = nullptr, const char* what = nullptr)
	{
		const auto status = MH_CreateHook((void*)address, (void*)target, (void**)orig);
		if (status != MH_OK)
		{
			logger::write("info", "!! MH_CreateHook(%s @ %p) failed: %s (%d)",
				what ? what : "?", (void*)address, MH_StatusToString(status), (int)status);
			return false;
		}

		// Enable THIS hook, and RETRY the transient failure.
		//
		// Two things were wrong here, and the second one only shows up on a busy
		// process.
		//
		// It used to enable MH_ALL_HOOKS after every single create, so installing
		// ~26 hooks re-walked every hook already created, 26 times, for no gain.
		//
		// And MinHook freezes threads before patching, which means
		// CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD) - a call that fails with
		// ERROR_BAD_LENGTH when the process's thread list changes while it is
		// being walked, and which Microsoft document as retryable. MinHook
		// reports that as MH_ERROR_MEMORY_ALLOC, which is a badly misleading
		// name: nothing has run out of memory, the snapshot just lost a race.
		//
		// It never bit while init happened ~90s in, on a quiet process. Moving
		// the FiveM path to attach+5s put it in the middle of CEF, V8 and mono
		// starting their thread pools, and most of the install started failing -
		// including the Export hook, which then reported itself as "patched over
		// by another mod". Retrying costs nothing when the snapshot succeeds.
		MH_STATUS en = MH_OK;
		int tries = 0;
		for (; tries < 20; ++tries)
		{
			en = MH_EnableHook((void*)address);
			if (en != MH_ERROR_MEMORY_ALLOC) break;   // i.e. not the snapshot race
			Sleep(15);
		}

		if (en != MH_OK)
		{
			logger::write("info", "!! MH_EnableHook(%s @ %p) failed after %d attempt(s): %s (%d)",
				what ? what : "?", (void*)address, tries + 1, MH_StatusToString(en), (int)en);
			return false;
		}

		// Worth one line: a hook that needed several goes is the signature of a
		// process too busy to snapshot, and that is a timing problem rather than
		// anything wrong with the hook itself.
		if (tries > 0)
			logger::write("info",
				"   %s: thread snapshot lost the race %d time(s) before the hook took",
				what ? what : "hook", tries);

		return true;
	}

	template<typename RetType, typename... Args>
	class func
	{
		using FuncType = RetType(__fastcall*)(Args...);
		FuncType mainFunc;

		std::string sig;
	public:
		func(const char* _sig) : sig(_sig), mainFunc(nullptr)
		{
			new InitFuncs([this] {
				this->run();
				});
		}

		void run()
		{
			mainFunc = memory::scan(sig.c_str()).as<FuncType>();
		}

		RetType operator()(Args...args)
		{
			return this->mainFunc(args...);
		}
	};

	static BOOL HookIAT(const char* szModuleName, const char* szFuncName, PVOID pNewFunc, PVOID* pOldFunc)
	{//https://guidedhacking.com/threads/how-to-hook-import-address-table-iat-hooking.13555/
#define PtrFromRva( base, rva ) ( ( ( PBYTE ) base ) + rva )

		PIMAGE_DOS_HEADER pDosHeader = (PIMAGE_DOS_HEADER)GetModuleHandle(NULL);
		PIMAGE_NT_HEADERS pNtHeader = (PIMAGE_NT_HEADERS)PtrFromRva(pDosHeader, pDosHeader->e_lfanew);

		if (pNtHeader->Signature != IMAGE_NT_SIGNATURE)
			return FALSE;

		PIMAGE_IMPORT_DESCRIPTOR pImportDescriptor = (PIMAGE_IMPORT_DESCRIPTOR)PtrFromRva(pDosHeader, pNtHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);

		for (UINT uIndex = 0; pImportDescriptor[uIndex].Characteristics != 0; uIndex++)
		{
			char* szDllName = (char*)PtrFromRva(pDosHeader, pImportDescriptor[uIndex].Name);

			if (_strcmpi(szDllName, szModuleName) != 0)
				continue;

			if (!pImportDescriptor[uIndex].FirstThunk || !pImportDescriptor[uIndex].OriginalFirstThunk)
				return FALSE;

			PIMAGE_THUNK_DATA pThunk = (PIMAGE_THUNK_DATA)PtrFromRva(pDosHeader, pImportDescriptor[uIndex].FirstThunk);
			PIMAGE_THUNK_DATA pOrigThunk = (PIMAGE_THUNK_DATA)PtrFromRva(pDosHeader, pImportDescriptor[uIndex].OriginalFirstThunk);

			for (; pOrigThunk->u1.Function != NULL; pOrigThunk++, pThunk++)
			{
				if (pOrigThunk->u1.Ordinal & IMAGE_ORDINAL_FLAG)
					continue;

				PIMAGE_IMPORT_BY_NAME import = (PIMAGE_IMPORT_BY_NAME)PtrFromRva(pDosHeader, pOrigThunk->u1.AddressOfData);

				if (_strcmpi(szFuncName, (char*)import->Name) != 0)
					continue;

				DWORD dwJunk = 0;
				MEMORY_BASIC_INFORMATION mbi;

				VirtualQuery(pThunk, &mbi, sizeof(MEMORY_BASIC_INFORMATION));
				if (!VirtualProtect(mbi.BaseAddress, mbi.RegionSize, PAGE_EXECUTE_READWRITE, &mbi.Protect))
					return FALSE;

				*pOldFunc = (PVOID*)(DWORD_PTR)pThunk->u1.Function;

				pThunk->u1.Function = (ULONGLONG)(DWORD_PTR)pNewFunc;

				if (VirtualProtect(mbi.BaseAddress, mbi.RegionSize, mbi.Protect, &dwJunk))
					return TRUE;
			}
		}
		return FALSE;
	}

	static bool HookApi(const wchar_t* module, const char* funcName, PVOID pNewFunc, PVOID* pOldFunc)
	{
		auto status = MH_CreateHookApi(module, funcName, pNewFunc, pOldFunc);
		if (status != MH_OK) {
			logger::write("info", " HookApi failed for %s: %d", funcName, (int)status);
			return false;
		}
		status = MH_EnableHook(MH_ALL_HOOKS);
		if (status != MH_OK) {
			logger::write("info", " MH_EnableHook failed: %d", (int)status);
			return false;
		}
		return true;
	}

	static memory scan(const char* signature, bool ignoreFail = false)
	{
		static auto pattern_to_byte = [](const char* pattern) {
			auto bytes = std::vector<int>{};
			auto start = const_cast<char*>(pattern);
			auto end = const_cast<char*>(pattern) + strlen(pattern);

			for (auto current = start; current < end; ++current) {
				if (*current == '?') {
					++current;
					if (*current == '?')
						++current;
					bytes.push_back(-1);
				}
				else {
					bytes.push_back(strtoul(current, &current, 16));
				}
			}
			return bytes;
			};

		auto moduleBase = base();

		auto dosHeader = (PIMAGE_DOS_HEADER)moduleBase;
		auto ntHeaders = (PIMAGE_NT_HEADERS)((std::uint8_t*)moduleBase + dosHeader->e_lfanew);

		constexpr auto offs = offsetof(IMAGE_DOS_HEADER, IMAGE_DOS_HEADER::e_lfanew);

		auto sizzz = sizeof(IMAGE_DOS_HEADER);

		auto sizeOfImage = ntHeaders->OptionalHeader.SizeOfImage;
		auto patternBytes = pattern_to_byte(signature);
		auto scanBytes = reinterpret_cast<std::uint8_t*>(moduleBase);

		auto s = patternBytes.size();
		auto d = patternBytes.data();

		for (auto i = 0ul; i < sizeOfImage - s; ++i) {
			bool found = true;
			for (auto j = 0ul; j < s; ++j) {
				if (scanBytes[i + j] != d[j] && d[j] != -1) {
					found = false;
					break;
				}
			}
			if (found) {
				return memory((uintptr_t)&scanBytes[i], false);
			}
		}
		if (!ignoreFail) {
			logger::write("info", " !! Pattern %s not found!", signature);
		}
		return memory(0, false);
	}

private:
	struct scoped_unlock
	{
		DWORD rights;
		size_t len;
		void* addr;

		scoped_unlock(uint64_t _addr, size_t _len) :addr((void*)_addr), len(_len)
		{
			VirtualProtect(addr, len, PAGE_EXECUTE_READWRITE, &rights);
		}

		~scoped_unlock()
		{
			VirtualProtect(addr, len, rights, NULL);
		}
	};
};